#include <asf.h>
#include <delay.h>
#include <test-more.h>
#include <ioport.h>
#include <lcd.h>
#include <adc.h>
#include <tc.h>


#ifdef __cplusplus
extern "C" {
#endif
#define LED_L_PORT PIOB
#define LED_L_PIN PIO_PB27

#define L1_IDX PIO_PC26_IDX

uint32_t n_on, n_off;
bool led_stanje =0;

int main (void)
{



    /* sets the processor clock according to conf_clock.h definitions */
    sysclk_init();

    /* disable wathcdog */
    WDT->WDT_MR = WDT_MR_WDDIS;

    /********************* HW init     ***************************/

    init_btn_leds();
    /* ioport_init();
     ioport_enable_pin(L1_IDX);
     ioport_set_pin_dir(L1_IDX ,IOPORT_DIR_OUTPUT);
     ioport_set_pin_level(L1_IDX ,1);
     delay_ms(500);
     ioport_set_pin_level(L1_IDX ,0); */





    sysclk_enable_peripheral_clock(ID_TC0);
    tc_init(TC0, 0, TC_CMR_TCCLKS_TIMER_CLOCK3 | TC_CMR_WAVE | TC_CMR_WAVSEL_UP_RC);
    tc_enable_interrupt(TC0, 0, TC_IER_CPCS);
    NVIC_EnableIRQ(TC0_IRQn);


    // init timer
    //systemcoreclock


    /********************* Main loop     ***************************/




    //tc_stop(Tc *p_tc, uint32_t ul_channel)



    //uint32_t t=10;
    uint8_t duty = 25;
    //uint32_t t0,t1;
    uint32_t f = 2;
    //double f_on = f*0.01*duty;
    uint32_t n = (SystemCoreClock/32)/f;
    n_on= (n*duty)/100;
    n_off= (n*(100-duty))/100;
    tc_write_rc(TC0,0,n_off);
    tc_start(TC0,0);

    lcd_init();
    //int konec = sprintf(lcd_string,"f=%lu Hz Duty=%lu",f,duty);
    //lcd_string[konec] =' ';
    lcd_driver();


    //to so procenti




    while(1)
    {

        int btn;
        btn = get_btn_press();
        if ((btn & (1<<0) )!= 0)
        {
            f += 1;
        }


        if ((btn & (1<<1) )!= 0)
        {
            f -= 1;
        }


        if ((btn & (1<<2) )!= 0)
        {
            duty += 5;
        }


        if ((btn & (1<<3) )!= 0)
        {
            duty -= 5;
        }


        if(f==0)
            f=1;
        if(duty >= 95)
            duty=95;
        if(duty <= 5)
            duty=5;

        n = (SystemCoreClock/32)/f;
        n_on= (n*duty)/100;
        n_off= (n*(100-duty))/100;

    lcd_init();
    sprintf(lcd_string,"VAJA 4");
    int konec = sprintf(lcd_string+16,"f=%lu Hz Duty=%lu",f,duty);
    lcd_string[konec+16] =' ';
    lcd_driver();
    lcd_driver();


    }

    /******************** varnost     ***************************/
    while(1)
    {


    }

}


void TC0_Handler(void)
{
    //ISR, prekinitvena rutina

    /** ce je led on => ugasni, nastavi RC na n_off**/
    /** ce LED off => prizgi, nastavi RC na n_on **/
    /** brisi IRQ zahtevo => beri status **/

    if(led_stanje==0)
    {
        ioport_set_pin_level(L1_IDX,1);
        tc_write_rc(TC0,0,n_on);
        led_stanje = 1;
    }
    else
    {

        ioport_set_pin_level(L1_IDX,0);
        tc_write_rc(TC0,0,n_off);
        led_stanje = 0;
    }

    tc_get_status(TC0, 0);


    /* if( NVIC_GetPendingIRQ(TC0_IRQn) ){
         //code too slow
     }
     */

}


#ifdef __cplusplus
}
#endif
