#include <asf.h>
#include <delay.h>
#include <test-more.h>
#include <ioport.h>
#include <lcd.h>
#include <adc.h>
#include <tc.h>


#ifdef __cplusplus
extern "C" {
#endif
#define LED_L_PORT PIOB
#define LED_L_PIN PIO_PB27

#define L1_IDX PIO_PC26_IDX

int main (void)
{

    /* sets the processor clock according to conf_clock.h definitions */
    sysclk_init();

    /* disable wathcdog */
    WDT->WDT_MR = WDT_MR_WDDIS;

    /********************* HW init     ***************************/

    // led lucka
    ioport_init();
    ioport_enable_pin(L1_IDX);
    ioport_set_pin_dir(L1_IDX ,IOPORT_DIR_OUTPUT);
    ioport_set_pin_level(L1_IDX ,0);




    sysclk_enable_peripheral_clock(ID_TC0);
    tc_init(TC0, 0, TC_CMR_TCCLKS_TIMER_CLOCK3 | TC_CMR_WAVE);
    tc_start(TC0, 0);


    // init timer
    //systemcoreclock


    /********************* Main loop     ***************************/

    //tc_write_rc(TC0, 0,uint32_t ul_value)


    //tc_stop(Tc *p_tc, uint32_t ul_channel)



    //uint32_t t=10;
    uint8_t duty = 25;
    //uint32_t t0,t1;
    uint32_t f = 2;
    //double f_on = f*0.01*duty;
    uint32_t n = SystemCoreClock/32/f;
    uint32_t n_on= n*duty/100;
    uint32_t n_off= n*(100-duty)/100;
    //to so procenti

    uint32_t n_zdaj, n_prej, n_delta;
    n_prej = tc_read_cv(TC0, 0);
    n_delta = n_off;

    while(1)
    {


    n_zdaj = tc_read_cv(TC0, 0);
    if(n_zdaj - n_prej > n_delta){
        if(n_delta == n_on){
            ioport_set_pin_level(L1_IDX ,0);
            n_delta=n_off;

            }

        else{
            ioport_set_pin_level(L1_IDX ,1);
            n_delta=n_on;

            }
            n_prej=n_zdaj;

        }

    }




     /******************** varnost     ***************************/
    while(1)
    {


    }

}

#ifdef __cplusplus
}
#endif
